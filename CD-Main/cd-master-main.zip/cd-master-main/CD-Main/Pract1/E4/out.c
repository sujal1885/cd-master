#include<stdioh>
int main()
{
int a=1;
printf("ichbin jhhaatu");

printf("laddha jhaatu")
}
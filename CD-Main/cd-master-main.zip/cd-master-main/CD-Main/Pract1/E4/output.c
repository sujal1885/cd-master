#include<stdio.h>
int main()
{
printf("saify Lodu");

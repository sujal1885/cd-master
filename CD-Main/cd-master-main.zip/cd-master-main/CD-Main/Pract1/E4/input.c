#include<stdio.h>
int main()
{
int a=1;
printf("ichbin jhhaatu");
/*this is a  prog*/
printf("laddha jhaatu")
}